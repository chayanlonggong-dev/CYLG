import { PrismaClient } from "@prisma/client";


const postgres = new PrismaClient();


async function main() {

  console.log("Starting data migration...");


  console.log(
    "This migration script is already completed."
  );


  console.log(
    "Current production database: PostgreSQL"
  );


}


main()

  .then(async () => {

    await postgres.$disconnect();

  })

  .catch(async (error) => {

    console.error(error);

    await postgres.$disconnect();

    process.exit(1);

  });