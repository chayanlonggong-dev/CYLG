"use client";

import {
  useState,
} from "react";

import Header from "../components/Header";
import Hero from "../components/Hero";
import Lifestyle from "../components/Lifestyle";
import Services from "../components/Services";
import LuxuryExperience from "../components/LuxuryExperience";
import CollectionCards from "../components/CollectionCards";
import FloatingContact from "../components/FloatingContact";
import HomeContactPopup from "../components/HomeContactPopup";
import Footer from "../components/Footer";


interface HomeClientProps {

  settings?: {

    siteName?: string;

    whatsapp?: string;
    telegram?: string;
    signal?: string;
    line?: string;
    wechatQr?: string;

    email?: string;


    enableWhatsapp?: boolean;
    enableTelegram?: boolean;
    enableSignal?: boolean;
    enableLine?: boolean;
    enableWechat?: boolean;

  };

}





export default function HomeClient({

  settings,

}: HomeClientProps) {



  const [
    isContactOpen,
    setIsContactOpen,
  ] = useState(false);





  return (

    <>


      <Header />

      <main className="pt-18 sm:pt-22 lg:pt-26">
        <Hero />

<Lifestyle />
<Services />
<LuxuryExperience />

<CollectionCards />
      </main>

      <FloatingContact

        onOpen={()=>
          setIsContactOpen(true)
        }

        email={
          settings?.email
        }

        showFeedback

      />







      <HomeContactPopup

        isOpen={
          isContactOpen
        }


        onClose={()=>
          setIsContactOpen(false)
        }



        whatsapp={
          settings?.whatsapp
        }


        telegram={
          settings?.telegram
        }


        signal={
          settings?.signal
        }


        line={
          settings?.line
        }


        wechatQr={
          settings?.wechatQr
        }


        email={
          settings?.email
        }



        enableWhatsapp={
          settings?.enableWhatsapp
        }


        enableTelegram={
          settings?.enableTelegram
        }


        enableSignal={
          settings?.enableSignal
        }


        enableLine={
          settings?.enableLine
        }


        enableWechat={
          settings?.enableWechat
        }


      />



    </>

  );

}