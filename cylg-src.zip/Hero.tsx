"use client";

import {
  useLanguage,
} from "@/app/providers/LanguageProvider";

export default function Hero() {
  const { messages } = useLanguage();

  const video = "/video/hero.mp4";

  return (
    <section
      id="hero"
      className="
        relative
        overflow-hidden
        min-h-[calc(100svh-4rem)]
        sm:min-h-[calc(100svh-5rem)]
      "
    >
      <video
        className="
          absolute
          inset-0
          h-full
          w-full
          object-cover
        "
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        onLoadedData={(e) => {
          e.currentTarget.play().catch(() => {});
        }}
      >
        <source
          src={video}
          type="video/mp4"
        />
      </video>

      <div
        className="
          absolute
          inset-0
          bg-black/70
        "
      />

      <div
        className="
          relative
          z-10
          flex
          min-h-[inherit]
          items-center
          justify-center
          px-6
          py-4
          sm:px-8
          sm:py-24
          lg:px-12
          lg:py-28
        "
      >
        <div
          className="
            mx-auto
            w-full
            max-w-4xl
            text-center
          "
        >
          <p
            className="
              text-[13px]
              uppercase
              tracking-[0.34em]
              text-yellow-400
              font-semibold
              sm:text-xs
              lg:text-sm
              lg:tracking-[0.35em]
            "
          >
            {messages.hero.title}
          </p>

          <p
            className="
              mt-9
              text-[2.55rem]
              font-semibold
              leading-none
              text-white
              sm:text-[5.775rem]
            "
            style={{
              fontFamily: "var(--font-cinzel)",
            }}
          >
            茶艳龙宫
          </p>

          <h1
            className="
              mt-1
              whitespace-nowrap
              text-[2.95rem]
              font-black
              leading-[0.94]
              tracking-[-0.04em]
              text-white
              sm:mt-5
              sm:text-[clamp(2.8rem,8vw,5.8rem)]
              sm:tracking-[-0.02em]
            "
          >
            ChaYanLongGong
          </h1>

          <h2
            className="
              mx-auto
              mt-4
              max-w-3xl
              text-[1.02rem]
              font-semibold
              leading-tight
              tracking-[0.18em]
              text-yellow-400
              sm:mt-5
              sm:text-3xl
              sm:font-bold
              sm:tracking-normal
              md:text-4xl
              lg:text-5xl
            "
          >
            {messages.hero.subtitle}
          </h2>

          <p
            className="
              mx-auto
              mt-5
              max-w-66
              text-[0.95rem]
              leading-6.5
              text-white
              sm:mt-9
              sm:max-w-2xl
              sm:text-lg
              sm:leading-9
              lg:max-w-4xl
              lg:text-xl
            "
          >
            {messages.hero.description}
          </p>

          <div
            className="
              mt-10
              flex
              justify-center
              sm:mt-10
            "
          >
            <a
              href="#collection"
              className="
                inline-flex
                min-h-14
                items-center
                justify-start
                rounded-full
                border
                border-yellow-500
                px-[1.35rem]
                py-3.5
                text-sm
                font-semibold
                text-yellow-400
                transition
                hover:bg-yellow-500
                hover:text-black
                sm:min-h-auto
                sm:px-10
                sm:py-4
                sm:text-lg
              "
            >
              {messages.hero.button}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}